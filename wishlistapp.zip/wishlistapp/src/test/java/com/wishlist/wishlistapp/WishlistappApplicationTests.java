package com.wishlist.wishlistapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishlistappApplicationTests {

	@Test
	void contextLoads() {
	}

}
